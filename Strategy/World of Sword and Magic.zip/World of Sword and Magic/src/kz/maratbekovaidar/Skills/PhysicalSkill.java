package kz.maratbekovaidar.Skills;

import kz.maratbekovaidar.SkillBehavior;

public class PhysicalSkill implements SkillBehavior {

    @Override
    public void useSkill(int HP, int magical_damage, int physical_damage) {
    }
}
