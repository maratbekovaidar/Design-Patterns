package kz.maratbekovaidar;

public interface SkillBehavior {
    public void useSkill(int HP, int magical_damage, int physical_damage);
}
